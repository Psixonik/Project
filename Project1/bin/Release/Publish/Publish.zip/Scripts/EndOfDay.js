﻿function MyFunc() {
    //alert("1");
    //Создание объекта для генерации чисел
    /*Random rnd = new Random();

    //Получить очередное (в данном случае - первое) случайное число
    int value = rnd.Next();
    let axez=2
    alert(value);*/
}